export interface Client{
    cName: string,
    cAddress: string,
    cCity: string,
    cPhoneNum: string,
    cEmail: string
}